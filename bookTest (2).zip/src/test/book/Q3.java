package test.book;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Q3 {
	String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	String USER = "c##madang";
	String PWD = "madang";
	Connection con;
	public Q3() {
		
//		JDBC Driver Memory에 Load한다.
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이버 로드 성공");
			
//		Connection 객체 생성
			con = DriverManager.getConnection(URL, USER, PWD);
			System.out.println("DB 연결 성공");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void runSQL() {
		Scanner scanner = new Scanner(System.in);
        System.out.println("[검색메뉴]");
        System.out.println("1. 도서명");
        System.out.println("2. 고객명");
        System.out.print("검색메뉴를 선택하세요 (1 또는 2를 입력): ");
        int choice = scanner.nextInt();
        scanner.nextLine();
		switch (choice) {
		case 1:
            System.out.print("도서명을 입력하세요: ");
            String bookname = scanner.nextLine();
            String sql = "select name, b.bookname, saleprice from customer c, book b, orders o where b.bookid=o.bookid AND c.custid=o.custid AND b.bookname like '%" + bookname + "%'";
            try {
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(sql);

                while (rs.next()) {
                    System.out.print("\t" + rs.getString("name"));
                    System.out.print("\t\t" + rs.getString("bookname"));
                    System.out.println("\t\t" + rs.getString("saleprice"));
                }

                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            break;
		case 2:
            System.out.print("고객명을 입력하세요: ");
            String customer = scanner.nextLine();
            String sql1 = "select name, b.bookname, saleprice from customer c, book b, orders o where b.bookid=o.bookid AND c.custid=o.custid AND name like '%" + customer + "%'";
            try {
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(sql1);

                while (rs.next()) {
                    System.out.print("\t" + rs.getString("name"));
                    System.out.print("\t\t" + rs.getString("bookname"));
                    System.out.println("\t\t" + rs.getString("saleprice"));
                }

                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            break;
		}
		
		
	}
		
	
	public static void main(String[] args) {
		Q3 bList = new Q3();
		bList.runSQL();
	}
}
